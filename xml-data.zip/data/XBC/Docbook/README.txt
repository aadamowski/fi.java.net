Sources for "Docbook: The Definitive Guide". Contributed by Norm Walsh.

